﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4
{
    class Program3
    {
        static void Main()
        {
           
            int[] a = new int[50];
            for (int i = 0; i < 50; i++)
            {
                a[i] = i+1;
            }
                Console.WriteLine("Odd one is:");
            foreach(int i in a)             {
                if (i % 2 != 0)
                {
                    Console.WriteLine(i);
                }
            }
        }
    }
}
