﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session4
{
    class Program4
    {
        static void Main()
        {
            Console.WriteLine("Enter the number");
            int a = Convert.ToInt32(Console.ReadLine());
              
            for (int i =1; i<= 10; i++)
            {
                Console.Write("{0} *{1} = {2} \n", a, i,a*i);
            }

            Console.ReadLine();
        }
    }
}
