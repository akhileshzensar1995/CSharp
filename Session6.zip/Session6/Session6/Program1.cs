﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6
{
    class Program1
    {
        int fact(int a)
        {
            int fact = 1;
                for(int i = 1; i <= a; i++)
            {
                fact = fact * i;
            }
            return fact;

        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number");
            int b = Convert.ToInt32(Console.ReadLine());
            Program1 p = new Program1();
            Console.WriteLine(p.fact(b));

            
           
        }
       
    }
}
