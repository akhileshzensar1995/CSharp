﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6
{
    class Program3
    {
        public double SimpleInterest (double amount, double time, double rate)
        {
            double si = (amount * time * rate) / 100;

            return si;
                 
        }
        public static void Main()
        {
            Console.WriteLine("Enter the Amount");
            double a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the Time");
            double b = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the Rate");
            double c = Convert.ToDouble(Console.ReadLine());

            Program3 p = new Program3();
            Console.WriteLine($"Simple Interst is : {p.SimpleInterest(a, b, c)}");
            Console.ReadLine();

        }
    }
}
