﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_9
{
    /// <summary>
    /// Extension Method :we can call a method by variabls Directly
    /// </summary>
    public static class IntExtension2
    {

        public static bool IsPositive(this int a, int value)
        {
            if (a > 0)
            {
                Console.WriteLine(value + a);
                Console.WriteLine("Positive");
                return true;
            }
            else
            {
                Console.WriteLine("Negative");
                return false;
            }
        }

    }



    class TestExtensionMethod
    {


        static void Main()
        {

            int i = 40; //we declare a integer
          //  bool result = i.ISGReaterThan(100);
            //Console.WriteLine(result ? "Greater" : " Smaller");
            Console.WriteLine(i.IsPositive(8));// we call method by variable

            Console.ReadLine();
        }
    }
}
