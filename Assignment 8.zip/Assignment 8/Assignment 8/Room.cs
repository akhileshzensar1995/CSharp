﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_8
{
    class Room
    {
        private int number;
        private int floor;
        private string type;
        private int capacity;
        private DateTime bookedTime;
        private double price;
        /// <summary>
        /// Hotel Requirement Properties
        /// </summary>



        public int RoomNumber
        {
            get
            {
                return number;
            }
            set
            {
                number = value;

            }
        }


        public int FloorNumber
        {

            get
            {
                return floor;
            }

            set
            {
                floor = value;
            }

        }


        public string RoomType
        {

            get
            {
                return type;
            }
            set
            {
                type = value;
            }

        }

        public int RoomCapacity
        {

            get
            {
                return capacity;
            }
            set
            {
                capacity = value;

            }
        }
        public DateTime BookingTime
        {
            get
            {
                return bookedTime;
            }
            set
            {
                bookedTime = value;
            }
        }

            public double RoomPrice
        {

            get
            {
                return price;
            }
            set
            {
                price = value;
            }

        }

        public Room() { }

        public Room(int number, int floor, string type, int capacity, DateTime bookedTime, double price) {
            this.number = number;
            this.floor = floor;
            this.type = type;
            this.capacity = capacity;
            this.bookedTime = bookedTime;
            this.price = price;
        }


        public override string ToString()
        {
            return (string.Format($"Number: {number}\n Floor: {floor}\n Type: {type}\n Capacity : {capacity}\n BookedTiming: {bookedTime}\n Price : {price}"));
        }

    }

    class HotelRequirement
    {
        static void Main()

        {
           // Room r = new Room() ;
            Console.WriteLine("Enter Room number : ");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter floor number :");
            int f = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter room Type: ");
            string t = (Console.ReadLine());
            Console.WriteLine("Enter the capacity  :");
            int c = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Booking timing :");
            DateTime bt = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter the price :");
            int p = Convert.ToInt32(Console.ReadLine());
            Room r = new Room(n, f, t, c, bt, p);


            Console.WriteLine(r.ToString());
            Console.ReadLine();



        }



    }




    }

