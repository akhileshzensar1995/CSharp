﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Character: ");
            char ch = Convert.ToChar(Console.ReadLine());
            int a = (int)ch;
            Console.WriteLine(a);
            Console.WriteLine("Enter the Integer: ");
            int b = Convert.ToInt32(Console.ReadLine());
            char ch1 = Convert.ToChar(b);
            Console.WriteLine(ch1);
            Console.ReadLine();
        }
    }
}
