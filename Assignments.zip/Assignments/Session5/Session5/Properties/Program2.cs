﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5.Properties
{
    class Program2
    {
        static void Main()
        {
            int sum = 0;
            int [,]a = { { 10, 40, 50 }, { 60, 20, 70 }, { 80, 90, 30 } };
            for(int i = 0; i<3; i++)
            {
                for(int j =0; j < 3; j++)
                {
                    if(i == j)
                    {
                        sum = sum + a[i, j];
                    }
                }
              
            }
            Console.WriteLine(sum);

        }
    }
}
