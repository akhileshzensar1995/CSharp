﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the length :");
            int l = Convert.ToInt32(Console.ReadLine());
            int[] a = new int[l];
            int sum = 0;
            for(int i =1; i<l; i++)
            {
                a[i] = i;
                sum = sum + a[i];
                }
            Console.WriteLine(sum);
            Console.ReadLine();
        }
        
    }
}
