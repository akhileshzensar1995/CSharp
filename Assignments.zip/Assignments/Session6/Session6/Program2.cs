﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session6
{
    class Program2
    {
        public void SearchElement(int num, int[][] a)
        {
            int count = 0;
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < a[i].Length; j++)
                {
                    if (num == a[i][j])
                    {
                        count++;
                    }

                }
            }
            if (count > 0)
            {
                Console.WriteLine("Number is found");
            }else
            {
                Console.WriteLine("Number is not found");
            }
            
        }
        public static void Main()
        {
            int[][] array = new int[2][];
            array[0] = new int[] { 1, 2, 3 };
            array[1] = new int[] { 4, 5 };
            Console.WriteLine("Enter a number");
            int b = Convert.ToInt32(Console.ReadLine());
            Program2 p = new Program2();
            p.SearchElement(b, array);


        }

    }
}
