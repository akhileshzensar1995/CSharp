﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {

            char ch = 'A';
            int a = (int)ch;
            Console.WriteLine(a);
            Console.ReadLine();

        }
    }
}
