﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            const double pi = 3.14;
            double r = 10;
            double area =  (pi * r * r);

            Console.WriteLine(area);
            Console.ReadLine();

        }
    }
}
