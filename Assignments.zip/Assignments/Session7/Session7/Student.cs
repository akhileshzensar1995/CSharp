﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session7
{
    class Students
    {
        static void Main()
        {
            Student s = new Student(11, "Ram", "Male", 952);
                Console.WriteLine(s.Display());
        }

    }
    
        
    
    struct Student
    {
        int rollNo;
            string Name;
        string Gender;
        int Mobilenumber;

        public Student(int rollNo,string Name,string Gender,int MobileNumber)
        {
            this.rollNo = rollNo;
            this.Name = Name;
            this.Gender = Gender;
            this.Mobilenumber = MobileNumber;
        }
        public string  Display()
        {
            return String.Format($"Student info: Roll no: {rollNo} Name : {Name} Gender : {Gender} MobileNumber : {Mobilenumber}");
        }

    }
}
