﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GST
{
    public class Gst
    {
        double amount;
        double GStPercent;
        double gstAmount = 5;

        public Gst(double amount)

        {
            this.amount = amount;
        }
         public string TotalGst()

        {
            gstAmount = amount * gstAmount/100;
            GStPercent = amount + gstAmount;
            return $"Your Gst is : {gstAmount}\n Your Total Amount including GSt {GStPercent}";
        }


    }
}
