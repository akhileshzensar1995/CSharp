﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5
{
    class Program5
    {
        static void Main()
        {

            char[,]a = { { 'a', 'b', 'c' },{ 'd','e','f'},{'g','h','i' } };

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.WriteLine(Convert.ToInt32(a[i,j]));
                } 
            }

        }
    }
}
