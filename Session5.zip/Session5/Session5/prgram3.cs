﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session5
{
    class prgram3
    {
        static void Main()
        {
            int[][] a = new int[2][];
            a[0] = new int[] { 1, 2, 3 };
            a[1] = new int[] { 4, 5 };

            Console.WriteLine("Enter a Element  to find ");
            int b = Convert.ToInt32(Console.ReadLine());
            int count =0;
            for(int i =0; i< 2; i++)
            {
                for (int j = 0; j < a[i].Length; j++)
                {
                    if (b== a[i][j]) {
                        count++;
                       
                    }

                }
                
            }
            if (count > 0)
            {
                Console.WriteLine("IS Found");
            }
            else
            {
                Console.WriteLine("Not found");
            }
            Console.ReadLine();
        }
    }
}
