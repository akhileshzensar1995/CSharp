﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Program4
    {
        static void Main()
        {
            Console.WriteLine("Enter the age: ");
            int age = Convert.ToInt32(Console.ReadLine());

            String Answer = age > 18 ? "Person is Major" : age < 18 ? " Person is Minor" : age == 18 ? "Person IS Still Major" : "No resule";
            Console.WriteLine(Answer);





        }
    }
}
